const AWS = require('aws-sdk');
const crypto = require("crypto");
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context, callback) => {
    
    const hash = crypto.createHash("md5");
    
    let params = {
        TableName: 'prodeo-users',
        Key: {
          "username": event.username,
        
        }
      }
     try {
         let result = await docClient.get(params).promise();
         if(result != null && result.Item.password ==  hash.update(event.password).digest("hex")){
            const expire = parseInt((Date.now()/1000) + 14400)
            const hash = crypto.randomBytes(25);
            const token = hash.toString("hex");
            let params = {
              TableName: 'prodeo-tokens',
              Item: {
                token,
                user: event.username,
                expire,
                role: result.Item.role,
              }
            }
            await docClient.put(params).promise();
            const returnData = {
                success: true,
                token,
                expire,
                role:result.Item.role
                
            }
            callback(null,returnData);
            return;
         }
        return {success: false, errorStr:"Username o password errate"}
     }catch(error){
         console.log(error)
         return {success: false, error}
     }
};
