const { checkToken } = require('./authorization.js');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
exports.handler = async (event) => {
  // TODO implement
  let user = await checkToken(event.Authorization);
  if (user == false) {
    return { success: false };
  }
  
  if (event.method == "list") {
    const _maps = await docClient.scan({ TableName: 'prodeo-maps' }).promise();
    let maps = [];
    for (let i in _maps.Items) {
      let devices = await docClient.scan({
        TableName: 'prodeo-devices',
        FilterExpression: 'mapCode = :mapCode',
        ExpressionAttributeValues: { ':mapCode': _maps.Items[i].mapCode }
      }).promise();
      _maps.Items[i].devices = devices.Items;
      if (user.role == "user") {
        
        for (let j in _maps.Items[i].devices) {
          if(user.devices.findIndex(d => d == _maps.Items[i].devices[j].deviceID) < 0){
            let minDev = {
              mapCode: _maps.Items[i].devices[j].mapCode,
              position: _maps.Items[i].devices[j].position,
              forbidden: true
            }
            _maps.Items[i].devices[j] = minDev;
          }
        }
      }
      maps.push(_maps.Items[i])
    }
    return { success: true, maps }
  }
  if (event.method == "values") {
    const devices = await docClient.scan({ TableName: 'prodeo-devices' }).promise();
    return { success: true, devices }
  }
};
