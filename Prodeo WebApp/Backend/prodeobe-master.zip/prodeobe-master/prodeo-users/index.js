
const { checkToken } = require('./authorization.js');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const crypto = require("crypto");
//const { DeleteCommand } = require("@aws-sdk/lib-dynamodb");
exports.handler = async (event, context, callback, a) => {

  let user = await checkToken(event.Authorization);
  if (user == false) {
    return { success: false };
  }

  if (user.role != "admin") {
    return { success: false };
  }

  if (event.type == "GET" && (event.username == null || event.username == "")) {
    let users = await docClient.scan({ TableName: 'prodeo-users' }).promise();
    return { success: true, users: users.Items }
  } else if (event.type == "GET" && event.username != null && event.username != "") {
    let user = await docClient.get({
      TableName: 'prodeo-users', Key: {
        username: event.username,

      }
    }).promise();
    return { success: true, user: user.Item }
  } else if (event.type == "POST") {
    let user = await docClient.get({
      TableName: 'prodeo-users', Key: {
        username: event.body.username,

      }
    }).promise();
    if (user.Item != undefined) {
      return { success: false, errorTxt: "La username inserita è già presente nel sistema" }
    }
    const hash = crypto.createHash("md5");
    event.body.password = hash.update(event.body.password).digest("hex");
    const params = {
      TableName: 'prodeo-users',
      Item: event.body
    }
    await docClient.put(params).promise();
    return { success: true }
  } else if (event.type == "PUT") {
    let user = await docClient.get({
      TableName: 'prodeo-users', Key: {
        username: event.body.username,

      }
    }).promise();
    if (user.Item == undefined) {
      return { success: false, errorTxt: "La username inserita è già presente nel sistema" }
    }
    const hash = crypto.createHash("md5");
    event.body.password = event.body.password == null || event.body.password == "" ? user.Item.password : hash.update(event.body.password).digest("hex");
    const params = {
      TableName: 'prodeo-users',
      Item: event.body,
      Key: {
        username: event.body.username,

      }
    }
    await docClient.put(params).promise();
    return { success: true }
  } else if (event.type == "DELETE") {
    /*return event;
    const username = event.username;
    const params = {
      TableName: 'prodeo-users',
      Key: {
        username: event.body.username,
      }
    }
    await docClient.send(new DeleteCommand(params));*/

    await docClient.delete({
      TableName: 'prodeo-users', Key: {
        username: event.username,

      }
    }).promise();
    return {success: true};
  }
  return event;



};
