
const { checkToken } = require('./authorization.js');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
exports.handler = async (event, context, callback, a) => {

	let user = await checkToken(event.Authorization);
	if (user == false) {
		return { success: false };
	}
	if (event.type == "GET" && (event.deviceID == undefined || event.deviceID == null)) {
		let devices = await docClient.scan({ TableName: 'prodeo-devices' }).promise();

		devices.Items  =  devices.Items.sort((a, b) => {
			if(b.name > a.name){
				return -1;
			}
			if(b.name < a.name){
				return 1;
			}
			return 0;
		})
		if (user.role == "admin") {
			return { success: true, devices: devices.Items }
		}
		let devs = [];
		for(let dev of devices.Items ){
			if(user.devices.findIndex(d => d == dev.deviceID) >= 0){
				devs.push(dev);
			}
		}
		
		return { success: true, devices: devs }
	}




};
