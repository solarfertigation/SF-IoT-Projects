const crypto = require("crypto");
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
exports.handler = async (event) => {
    
    let date = new Date();
    const month = date.getMonth();
    const day = date.getDay();
    const data = date.getDate();
    const year = date.getFullYear();
    const hour = date.getHours();
    const minutes = date.getMinutes();
    let quarter_hour = 0;
    if(minutes >= 15){
        quarter_hour = 15;
    }
    if(minutes >= 30){
        quarter_hour = 30;
    }
     if(minutes >= 45){
        quarter_hour = 45;
    }
    
    let trimester = Math.floor((month + 3) / 3);
    
  
    if(event.ZbReceived != undefined){
        for(let i in event.ZbReceived){
            const data = event.ZbReceived[i]
            const deviceName = i.trim();
            const deviceId = data.Device.replace("0x","");
            
            let uniqueid = `${deviceId}-${date.getTime()}`
            const hash = crypto.createHash("md5");
            uniqueid = hash.update(uniqueid).digest("hex");
            const params = {
              TableName: 'prodeo-events',
              Item: {
                  uniqueid,
                  deviceName,
                  deviceId,
                  timestamp: date.getTime(),
              }
            }
            let device = await docClient.get({
            TableName: 'prodeo-devices', Key: {
              deviceID: deviceId,
            
            }}).promise();   
            device = device.Item;
            if(device.lastValue == null){
                device.lastValue = {};
            }
            device.lastValue.timestamp = date.getTime();
            if(data.Temperature != undefined){
                params.Item.temperature = data.Temperature;
                device.lastValue.temperature = data.Temperature;
            }
            if(data.Humidity != undefined){
                params.Item.humidity = data.Humidity;
                device.lastValue.humidity = data.Humidity;
            }
            let hasWater = false;
            if(data.Water != undefined){
                hasWater = true;
                params.Item.water = data.Water;
                device.lastValue.water = data.Water;
            }
            if(data.BatteryPercentage != undefined){
                params.Item.batteryPercentage = data.BatteryPercentage;
                device.lastValue.batteryPercentage = data.BatteryPercentage;
            }
            if(data.BatteryVoltage != undefined){
                params.Item.batteryVoltage = data.BatteryVoltage;
                device.lastValue.batteryVoltage = data.BatteryVoltage;
            }
            await docClient.put(params).promise();
            
            
            const paramsdevices = {
              TableName: 'prodeo-devices',
              Item: device,
              Key: {
                  deviceID: deviceId,
                
                }
            }
          //  
            if(hasWater && params.Item.water == 1){

                let last = await docClient.get(paramsdevices).promise();
                let mapCode = last.Item.mapCode;
                let mappa = await docClient.get( {
                    TableName: 'prodeo-maps',
                    Item: device,
                    Key: {
                        mapCode
                      
                      }
                  }).promise();
                  let administrators = await docClient.scan( {
                    TableName: 'prodeo-users',
                    FilterExpression: '#role = :role',
                    ExpressionAttributeValues: { ':role': 'admin' },
                    ExpressionAttributeNames: { '#role': 'role' }
                  }).promise();

                let numbers = []
                for(let i in administrators.Items){
                    let mobileNumbers = administrators.Items[i].mobileNumbers.split(",");
                    for(let j in mobileNumbers){
                        let numb = mobileNumbers[j].trim();
                        if(numb != ""){
                            numbers.push("+39"+numb);
                        }
                    }
                }
                
                if(last.Item.lastValue.water == 0){
                    const SNSClient = new AWS.SNS({apiVersion: '2010-03-31'});
                    var paramsAttSms = {
                        attributes: { /* required */
                          'DefaultSMSType': 'Transactional', /* highest reliability */
                          "DefaultSenderID": "ProdeoIOT"

                        }
                      };
                    await SNSClient.setSMSAttributes(paramsAttSms).promise();
                    const date = new Date();
                    const strDate = date.toLocaleString('it-IT', { timeZone: 'Europe/Rome' })
                    const testo = `Allerta sensore ${last.Item.name}(${mappa.Item.name}) ACQUA rilevata in data ${strDate}`;
                    
                    
                    for(let i in numbers){

                    
                        var paramsSMS = {
                            Message: testo, /* required */
                            PhoneNumber: numbers[i],
                            
                        };
                        const data = await SNSClient.publish(paramsSMS).promise();
                        console.log(data);
                        console.log(paramsSMS);
                    }
                    
                    
                }
            }
            await docClient.put(paramsdevices).promise();
        }
    }
};
