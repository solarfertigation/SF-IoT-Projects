const { getEvent } = require("./model.js");
exports.shwoValues = async (body) => {
  let events = await getEvent(body);
  let dates = new Date(body.dateStart);
  let datee = new Date(body.dateEnd);
  let sampling = body.sampling;
  let listaDati = {
    temperature: [
      {
        field: "temperature",
        name: "Temperatura",
        type: "avg",
        sum: 0,
        elem: 0
      }
    ],
    humidity: [
      {
        field: "humidity",
        name: "Umidità",
        type: "avg",
        sum: 0,
        elem: 0
      }
    ],
    batteryPercentage: [
      {
        field: "batteryPercentage",
        name: "Percentuale batteria",
        type: "avg",
        sum: 0,
        elem: 0
      }
    ],
    batteryVoltage: [
      {
        field: "batteryVoltage",
        name: "Tensione batteria",
        type: "avg",
        sum: 0,
        elem: 0
      }
    ],
    water: [
      {
        field: "water",
        name: "Presenza acqua",
        type: "max",
        sum: 0,
        elem: 0,

      }
    ]
  }
  let dati = listaDati[body.property];
 // return dati;
  let date = [];
  if (sampling == '1d') {
    for (let dt = dates; dt <= datee; dt.setDate(dt.getDate() + 1)) {
      let end = new Date(JSON.parse(JSON.stringify(dt)));
      end.setHours(23);
      end.setMinutes(59);
      end.setSeconds(59);
      let label = {
        start: JSON.parse(JSON.stringify(dt)),
        end: JSON.parse(JSON.stringify(end)),
        label: `${formatedate(dt)}`,
        dati: JSON.parse(JSON.stringify(dati)),
      }
      date.push(label);
    }
  }
  if (sampling == '1m') {
    for (let dt = dates; dt <= datee; dt.setMonth(dt.getMonth() + 1)) {

      let start = new Date(JSON.parse(JSON.stringify(dt)));
      start.setDate(1);
      start.setHours(23);
      start.setMinutes(59);
      start.setSeconds(59);
      let end = new Date(JSON.parse(JSON.stringify(lastDayOfMonth(dt.getFullYear(), dt.getMonth() + 1))));


      end.setHours(23);
      end.setMinutes(59);
      end.setSeconds(59);
      let label = {
        start: JSON.parse(JSON.stringify(start)),
        end: JSON.parse(JSON.stringify(end)),
        label: `${formatedate(dt)}`.substr(3, 10),
        dati: JSON.parse(JSON.stringify(dati)),
      }
      date.push(label);
    }
  }
  if (sampling == '1h') {
    for (let i = 0; i <= 23; i++) {
      let start = new Date(JSON.parse(JSON.stringify(datee)));
      start.setHours(i);
      start.setMinutes(0);
      start.setSeconds(0);
      let end = new Date(JSON.parse(JSON.stringify(datee)));
      end.setHours(i);
      end.setMinutes(59);
      end.setSeconds(59);
      let label = {
        start: JSON.parse(JSON.stringify(start)),
        end: JSON.parse(JSON.stringify(end)),
        label: `${i}:00:00 - ${i}:59:59`,
        dati: JSON.parse(JSON.stringify(dati)),
      }
      date.push(label);
    }
  }
  if (sampling == '15m') {
    for (let i = 0; i <= 23; i++) {
      let start = new Date(JSON.parse(JSON.stringify(datee)));
      start.setHours(i);
      start.setMinutes(0);
      start.setSeconds(0);
      let end = new Date(JSON.parse(JSON.stringify(datee)));
      end.setHours(i);
      end.setMinutes(14);
      end.setSeconds(59);
      let label = {
        start: JSON.parse(JSON.stringify(start)),
        end: JSON.parse(JSON.stringify(end)),
        label: `${i}:00:00 - ${i}:14:59`,
        dati: JSON.parse(JSON.stringify(dati)),
      }
      date.push(label);


      let start2 = new Date(JSON.parse(JSON.stringify(datee)));
      start2.setHours(i);
      start2.setMinutes(15);
      start2.setSeconds(0);
      let end2 = new Date(JSON.parse(JSON.stringify(datee)));
      end2.setHours(i);
      end2.setMinutes(29);
      end2.setSeconds(59);
      let label2 = {
        start: JSON.parse(JSON.stringify(start2)),
        end: JSON.parse(JSON.stringify(end2)),
        label: `${i}:15:00 - ${i}:29:59`,
        dati: JSON.parse(JSON.stringify(dati)),
      }
      date.push(label2);


      let start3 = new Date(JSON.parse(JSON.stringify(datee)));
      start3.setHours(i);
      start3.setMinutes(30);
      start3.setSeconds(0);
      let end3 = new Date(JSON.parse(JSON.stringify(datee)));
      end3.setHours(i);
      end3.setMinutes(44);
      end3.setSeconds(59);
      let label3 = {
        start: JSON.parse(JSON.stringify(start3)),
        end: JSON.parse(JSON.stringify(end3)),
        label: `${i}:30:00 - ${i}:44:59`,
        dati: JSON.parse(JSON.stringify(dati)),
      }
      date.push(label3);

      let start4 = new Date(JSON.parse(JSON.stringify(datee)));
      start4.setHours(i);
      start4.setMinutes(45);
      start4.setSeconds(0);
      let end4 = new Date(JSON.parse(JSON.stringify(datee)));
      end4.setHours(i);
      end4.setMinutes(59);
      end4.setSeconds(59);
      let label4 = {
        start: JSON.parse(JSON.stringify(start4)),
        end: JSON.parse(JSON.stringify(end4)),
        label: `${i}:45:00 - ${i}:59:59`,
        dati: JSON.parse(JSON.stringify(dati)),
      }
      date.push(label4);

    }
  }

  for (let ev of events) {
    
    if (ev[body.property] == undefined || ev[body.property] == null) {
      continue;
    }
    let dateindex = date.findIndex(d => new Date(d.start) <= new Date(ev.timestamp) && new Date(d.end) >= new Date(ev.timestamp));
    if (dateindex < 0) {
      continue;
    }
    for (let i in date[dateindex].dati) {
      if (date[dateindex].dati[i] == "max") {
        if (date[dateindex].dati[i].sum < parseFloat(ev[date[dateindex].dati[i].field])) {
          date[dateindex].dati[i].sum = parseFloat(ev[date[dateindex].dati[i].field]);
        }
      } else {
        date[dateindex].dati[i].sum += parseFloat(ev[date[dateindex].dati[i].field]);
      }

      date[dateindex].dati[i].elem++;
    }
  }
  if(body.type == "tachometer"){
    let tot = 0;
    let elem = 0;
    is_avg = false;
    for (let dateindex in date) {
      for (let i in date[dateindex].dati) {
        if (date[dateindex].dati[i] == "max") {
          if(tot < date[dateindex].dati[i].sum)
          {
            tot = date[dateindex].dati[i].sum;
          }
        }else{
          tot += date[dateindex].dati[i].sum;
        }
        elem += date[dateindex].dati[i].elem;
        if(date[dateindex].dati[i].type == "avg"){
          is_avg = true;
        }
      }
    }
    if(is_avg){
      tot /= elem;
    }
    let ret = {
      value:tot,
      type: body.type,
      index: body.index,
    }
    return ret;
  }
  lineChartData = [];
  lineChartLabels = [];
  for (let dateindex in date) {
    lineChartLabels.push(date[dateindex].label)
    for (let i in date[dateindex].dati) {
      if (date[dateindex].dati[i].sum > 0 && date[dateindex].dati[i].type == "avg") {
        date[dateindex].dati[i].sum /= date[dateindex].dati[i].elem
      }
      if (lineChartData[i] == null) {
        lineChartData[i] = {
          label: date[dateindex].dati[i].name,
          data: [],
        };
      }
      lineChartData[i].data.push(date[dateindex].dati[i].sum)
    }
  }
  let ret = {
    lineChartData,
    lineChartLabels,
    type: body.type,
    index: body.index,
  }
  return ret;

  

  // return events;
}

function formatedate(dt){
  let month = dt.getMonth()+1;
  month = month>=10?month:`0${month}`;
  let day = dt.getDate();
  day = day>=10?day:`0${day}`;
  let year = dt.getFullYear();
  return `${day}/${month}/${year}`;
  
}

const lastDayOfMonth = (year, month) => {
  return new Date((new Date(year, month, 1)) - 1);
}