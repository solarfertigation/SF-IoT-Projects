const {getDashboardList, createDashboard} = require("./model.js");

exports.dashboardList = async (user) => {
  let dashboard = await getDashboardList(user);
  if(dashboard.Items.length == 0){
    await createDashboard(user,"Dashboard 1");
    dashboard = await getDashboardList(user);
  }
  return dashboard.Items;
}