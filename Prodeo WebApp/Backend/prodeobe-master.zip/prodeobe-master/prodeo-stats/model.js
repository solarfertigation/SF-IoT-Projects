const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const crypto = require("crypto");
exports.getDashboardList = async (user) => {
  const dashboard = await docClient.scan({
    TableName: 'prodeo-dashboard',
    FilterExpression: 'username = :username',
    ExpressionAttributeValues: { ':username': user.username }
  }).promise();
  return dashboard;
}

exports.getDeviceById = async (deviceID) => {
  const seplectParams = {
    TableName: 'prodeo-devices',
    Key: {
      deviceID
    
    }
  }
  
  let device = await docClient.get(seplectParams).promise();
  device = device.Item;
  return device
}
exports.getEvent = async (body) => {
  const dateStart = new Date(body.dateStart);
  dateStart.setHours(0);
  dateStart.setMinutes(0);
  dateStart.setSeconds(0);

  const dateEnd = new Date(body.dateEnd);
  dateEnd.setHours(23);
  dateEnd.setMinutes(59);
  dateEnd.setSeconds(59);

  const search = {
    TableName: 'prodeo-events',
    FilterExpression: '#deviceId = :deviceId and #dateStart >= :dateStart  and #dateEnd <= :dateEnd',
    ExpressionAttributeNames: { 
      '#deviceId':"deviceId",
      '#dateStart':"timestamp",
      '#dateEnd':"timestamp",
    },
    ExpressionAttributeValues: { 
      ':deviceId': body.device_id,
      ':dateStart':  dateStart.getTime(),
      ':dateEnd':  dateEnd.getTime(),
    }
  }
  
  const events = await docClient.scan(search).promise();
  return events.Items;
}
exports.deleteDashboard = async (uniqueid) => {
  const seplectParams = {
    TableName: 'prodeo-dashboard',
    Key: {
      uniqueid
    
    }
  }
  
  await docClient.delete(seplectParams).promise();
  
  return {success: true}
}
exports.getDashboard = async (uniqueid) => {
  const seplectParams = {
    TableName: 'prodeo-dashboard',
    Key: {
      uniqueid
    
    }
  }
  
  let dashboard = await docClient.get(seplectParams).promise();
  dashboard = dashboard.Item;
  return dashboard
}
exports.renameDashboard = async (uniqueid,name) => {
  const seplectParams = {
    TableName: 'prodeo-dashboard',
    Key: {
      uniqueid
    
    }
  }
  
  let dashboard = await docClient.get(seplectParams).promise();
  dashboard = dashboard.Item;
  dashboard.name = name;
  const params = {
    TableName: 'prodeo-dashboard',
    Item: dashboard,
    Key: {
      uniqueid,
      
    }
  }
  
  await docClient.put(params).promise();
  return {success:true}
}
exports.updateData = async (body) => {
  const uniqueid = body.uniqueid;
  const data = body.data;
  const seplectParams = {
    TableName: 'prodeo-dashboard',
    Key: {
      uniqueid
    
    }
  }
  let dashboard = await docClient.get(seplectParams).promise();
  dashboard = dashboard.Item;
  dashboard.data = data;
  const params = {
    TableName: 'prodeo-dashboard',
    Item: dashboard,
    Key: {
      uniqueid,
      
    }
  }
  await docClient.put(params).promise();
  return {success:true}
  
}
exports.createDashboard = async (user, name) => {
  
  const date = new Date();
  let uniqueid = `${user.username}-${name}-${date.getTime()}`
  const hash = crypto.createHash("md5");
  uniqueid = hash.update(uniqueid).digest("hex");
  const params = {
    TableName: 'prodeo-dashboard',
    Item: {
      uniqueid,
      name,
      username:user.username,
      data: {},

    }
  }
  await docClient.put(params).promise();
  return uniqueid;
}