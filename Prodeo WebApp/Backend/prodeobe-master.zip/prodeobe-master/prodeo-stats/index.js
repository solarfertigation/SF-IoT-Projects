const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const { checkToken } = require('./authorization.js');
const { dashboardList } = require('./dashboardList.js');
const { updateData, createDashboard, renameDashboard, getDashboard, deleteDashboard, getDeviceById } = require('./model.js');
const { shwoValues } = require('./values.js');
exports.handler = async (event) => {
  let user = await checkToken(event.Authorization);
  if (user == false) {
    return { success: false };
  }
  if (event.type == "GET" && event.method == "list") {
    return dashboardList(user);
  }
  if (event.type == "PUT" && event.method == "data") {
    return updateData(event.body);
  }
  if (event.type == "POST" && event.method == "values") {

    if (user.role == "user" && user.devices.findIndex(d => d == event.body.device_id) < 0) {
      return { success: false };
    }
    if (event.body.type == "tachometer") {
      
      const device = await getDeviceById(event.body.device_id);
 
      let ret = {
        value: device && device.lastValue && device.lastValue[event.body.property]?device.lastValue[event.body.property]:null,
        type: event.body.type,
        index: event.body.index,
      }
      return ret;
    }
    return shwoValues(event.body);
  }
  if (event.type == "POST" && event.method == "dashboard") {

    return createDashboard(user, event.body.dashboard_name);
  }
  if (event.type == "PUT" && event.method == "dashboard") {

    return renameDashboard(event.uniqueid, event.body.dashboard_name);
  }
  if (event.type == "GET" && event.method == "dashboard") {

    return getDashboard(event.uniqueid);
  }
  if (event.type == "DELETE" && event.method == "dashboard") {

    return deleteDashboard(event.uniqueid);
  }
  return event;
};
