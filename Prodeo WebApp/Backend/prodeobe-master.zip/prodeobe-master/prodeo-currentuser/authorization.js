const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
exports.checkToken = async(token) => {
    token = token.replace("Bearer ","");
    console.log("token", token);
      let params = {
        TableName: 'prodeo-tokens',
        Key: {
          token,
        
        }
      }
     try {
         let result = await docClient.get(params).promise();
         if(result.Item == undefined){
             return false;
         }
         let paramsuser = {
            TableName: 'prodeo-users',
            Key: {
              username:result.Item.user,
            
            }
          }
          let user = await docClient.get(paramsuser).promise();
          return user.Item;
     }catch(error){
         console.log(error);
     }
}