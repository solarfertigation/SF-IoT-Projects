
const {checkToken} = require('./authorization.js');
exports.handler = async (event,context,callback,a) => {
    let user = await checkToken(event.Authorization);
    if(user==false){
        return {success:false};
    }
    return {success:true, user}
};
